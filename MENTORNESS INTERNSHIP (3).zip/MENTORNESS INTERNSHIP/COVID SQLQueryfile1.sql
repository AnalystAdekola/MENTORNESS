--- Q1. Write a code to check NULL values

Select *
From CO.dbo.Corona_Virus_Dataset
where Province is NULL OR [Country Region] is null or Latitude is null or Longitude is null or Date is null or Confirmed is null or Deaths is null or Recovered is null;

--- Q2. If NULL values are present, update them with zeros for all columns. 

--- No Null value is present.

--- Q3. check total number of rows
Select *
From CO.dbo.Corona_Virus_Dataset

--- Q4. Check what is start_date and end_date

Select Date
From CO.dbo.Corona_Virus_Dataset
Order by year (Date), month (Date), Day (Date) Asc;

--- Start Date is 02-Jan-2020

Select Date
From CO.dbo.Corona_Virus_Dataset
Order by year (Date), month(Date), day(Date) Desc;

---End Date is 06-Dec-2021

--- Q5. Number of month present in dataset

SELECT COUNT(DISTINCT MONTH(Date)) AS distinct_months
FROM CO.dbo.Corona_Virus_Dataset;

---We have 12 Months

--- Q6. Find monthly average for confirmed, deaths, recovered
SELECT 
  YEAR(Date) AS year,
  MONTH(Date) AS month,
  AVG(Confirmed) AS avg_confirmed,
  AVG(Deaths) AS avg_deaths,
  AVG(Recovered) AS avg_recovered
FROM CO.dbo.Corona_Virus_Dataset
GROUP BY YEAR(Date), MONTH(Date)
ORDER BY year, month;

--- Q7. Find most frequent value for confirmed, deaths, recovered each month 


--- Q8. Find minimum values for confirmed, deaths, recovered per year

Select year(Date) as Year_CO, min(Confirmed) as min_confirmed, min(Deaths) as min_deaths, min(Recovered) as min_recovered
From CO.dbo.Corona_Virus_Dataset
Group by Year(Date);

--- Q9. Find maximum values of confirmed, deaths, recovered per year

Select year(Date) as Year_CO, max(Confirmed) as max_confirmed, max(Deaths) as max_deaths, max(Recovered) as max_recovered
From CO.dbo.Corona_Virus_Dataset
Group by Year(Date);

--- Q10. The total number of case of confirmed, deaths, recovered each month

Select month (Date) as Month_Sum, sum(Confirmed) as sum_confirmed, sum(Deaths) as sum_deaths, sum(Recovered) as sum_recovered
From CO.dbo.Corona_Virus_Dataset
Group by Month (Date)
Order by Month_Sum;

---Q11. Check how corona virus spread out with respect to confirmed case
     ---(Eg.: total confirmed cases, their average, variance & STDEV )

Select Year (Date) as Year_Spread, sum(Confirmed) as sum_confirmed,avg(Confirmed) as avg_confirmed, var(Confirmed) as var_Confirmed, stdev(Confirmed) as stdev_Confirmed
From CO.dbo.Corona_Virus_Dataset
Group by Year (Date)
Order by Year_Spread;

---Q12. Check how corona virus spread out with respect to death case per month
     ---(Eg.: total confirmed cases, their average, variance & STDEV )

Select month (Date) as Month_Spread, sum(Deaths) as sum_deaths, avg(Deaths) as avg_Deaths, var(Deaths) as var_Deaths, stdev(Deaths) as stdev_Deaths
From CO.dbo.Corona_Virus_Dataset
Group by Month (Date)
Order by Month_Spread;

---Q13. Check how corona virus spread out with respect to recovered case
   ---(Eg.: total confirmed cases, their average, variance & STDEV )

Select Year (Date) as Year_Spread, sum(Recovered) as sum_Recovered,avg(Recovered) as avg_Recovered, var(Recovered) as var_Recovered, stdev(Recovered) as stdev_Recovered
From CO.dbo.Corona_Virus_Dataset
Group by Year (Date)
Order by Year_Spread;

---Q14. Find Country having highest number of the Confirmed case

Select[Country Region], sum(confirmed) as Confirmed_Count
From CO.dbo.Corona_Virus_Dataset
Group by [Country Region]
Order by Confirmed_Count Desc;

---The Country with the highest number of confirmed cases is the United States of America

---Q15. Find Country having lowest number of the death case

Select[Country Region], sum(Deaths) as Death_Count
From CO.dbo.Corona_Virus_Dataset
Group by [Country Region]
Order by Death_Count;

---The country with the lowest death case; Marshall Islands, Samoa, Dominica, Kribati

---Q16. Find top 5 countries having highest recovered case

Select[Country Region], sum(Recovered) as Recovered_Count
From CO.dbo.Corona_Virus_Dataset
Group by [Country Region]
Order by Recovered_Count desc;

---The top 6 countries with the highest recovered cases are; 
---India
---Brazil
---United States Of America
---Turkey
---Russia
---Italy


